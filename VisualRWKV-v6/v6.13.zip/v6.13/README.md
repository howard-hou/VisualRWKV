# VisualRWKV: A Visual-Enhanced RWKV

## tl;dr
VisualRWKV-UHD: Ultra-High-Definition, up to 4K resolution, 4096x4096 pixels.