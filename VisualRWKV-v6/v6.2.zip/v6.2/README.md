# VisualRWKV: A Visual-Enhanced RWKV

## tl;dr
v6.2: add state tuning